/*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
import { Profit, sequelize } from "../models/Profit.js";
await sequelize.sync();
const profit ={
  index: async (req, res) => {
    res.send("Index Page");
  },
  insert: async (req, res) => {
    const {
      TotalSales, TotalCost, ProfitAmount, SalesDate } = req.body;

    const e = await Profit.create({
      TotalSales, TotalCost, ProfitAmount, SalesDate
    });

    res.status(201).json({
      "status": "true",
      "data": e
    });
  },

  all: async (req, res) => {
    const data = await Profit.findAll();
    res.json({
      "data": data
    });
  },

  byId: async (req, res) => {
    const data = await Profit.findByPk(req.params.id);
    res.json({
      "data": data
    });
  }
};
export { profit };